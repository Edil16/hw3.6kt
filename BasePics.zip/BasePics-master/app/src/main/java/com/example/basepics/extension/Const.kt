package com.example.basepics.extension

const val KEY:String="key"