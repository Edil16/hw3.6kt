package com.example.basepics.ui.pics

import com.example.basepics.base.BaseViewModel

class PicsViewModel : BaseViewModel() {

}