package com.example.basepics.ui.main

import com.example.basepics.base.BaseViewModel

class MainViewModel:BaseViewModel() {
}